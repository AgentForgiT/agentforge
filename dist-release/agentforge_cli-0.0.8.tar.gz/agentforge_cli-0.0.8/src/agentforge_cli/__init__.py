"""AgentForge CLI."""

